from sklearn.linear_model import LinearRegression
import numpy as np, scipy.optimize
import numpy.linalg as la
import pandas as pd

# import my modules
from my_args import setup_argparse 
from gd_poisoners import *


def open_dataset(f,visualize):
  if visualize:
    raise NotImplementedError
  else:
    x,y = read_dataset_file(f)

  return np.matrix(x), y

def read_dataset_file(f):
  with open(f) as dataset:
    x = []
    y = []
    cols = dataset.readline().split(',')
    print(cols)
    
    global colmap
    colmap = {}
    for i, col in enumerate(cols):
      if ':' in col:
        if col.split(':')[0] in colmap:
          colmap[col.split(':')[0]].append(i-1)
        else:
          colmap[col.split(':')[0]] = [i-1]
    for line in dataset:
      line = [float(val) for val in line.split(',')]
      y.append(line[0])
      x.append(line[1:])
     
    return np.matrix(x), y

# ------------------------------------------------------------------------------- 
def open_logging_files(logdir,modeltype,logind,args):
  myname = str(modeltype)+str(logind)
  logdir = logdir + os.path.sep + myname
  if not os.path.exists(logdir):
    os.makedirs(logdir)
  with open(os.path.join(logdir,'cmd'),'w') as cmdfile:
    cmdfile.write(' '.join(['python3'] + argv))
    cmdfile.write('\n')
    for arg in args.__dict__:
      cmdfile.write('{}: {}\n'.format(arg,args.__dict__[arg]))

  trainfile = open(logdir + os.path.sep + "train.txt",'w')
  testfile = open(logdir + os.path.sep + "test.txt",'w')
  validfile = open(logdir + os.path.sep + "valid.txt",'w')
  resfile = open(logdir + os.path.sep + "err.txt",'w')
  resfile.write('poisct,itnum,obj_diff,obj_val,val_mse,test_mse,time\n')
  return trainfile,testfile,validfile,resfile,logdir


# ------------------------------------------------------------------------------- 
def sample_dataset(x, y, trnct, poisct, tstct, vldct, seed):
    size = x.shape[0]
    print(size)
    
    np.random.seed(seed)
    fullperm = np.random.permutation(size)

    sampletrn = fullperm[:trnct]
    sampletst = fullperm[trnct:trnct + tstct]
    samplevld = fullperm[trnct + tstct:trnct + tstct + vldct]
    samplepois = np.random.choice(size, poisct)

    trnx = np.matrix([np.array(x[row]).reshape((x.shape[1],)) for row in sampletrn])
    trny = [y[row] for row in sampletrn]
   
    tstx = np.matrix([np.array(x[row]).reshape((x.shape[1],)) for row in sampletst])
    tsty = [y[row] for row in sampletst]
    
    
    poisx = np.matrix([np.array(x[row]).reshape((x.shape[1],)) for row in samplepois])
    poisy = [y[row] for row in samplepois]

    vldx = np.matrix([np.array(x[row]).reshape((x.shape[1],)) for row in samplevld])
    vldy = [y[row] for row in samplevld]
    
    return trnx, trny, tstx, tsty, poisx, poisy, vldx, vldy

    # ------------------------------------------------------------------------------- 
def sample_dataset_byInfluence(x, y, trnct, poisct, tstct, vldct, seed):#
    size = x.shape[0]
    print(size)
    
    np.random.seed(seed)
    fullperm = np.random.permutation(size)

    sampletrn = fullperm[:trnct]
    sampletst = fullperm[trnct:trnct + tstct]
    samplevld = fullperm[trnct + tstct:trnct + tstct + vldct]
    #samplepois = np.random.choice(size, poisct)

    trnx = np.matrix([np.array(x[row]).reshape((x.shape[1],)) for row in sampletrn])
    trny = [y[row] for row in sampletrn]
   
    tstx = np.matrix([np.array(x[row]).reshape((x.shape[1],)) for row in sampletst])
    tsty = [y[row] for row in sampletst]
        
    vldx = np.matrix([np.array(x[row]).reshape((x.shape[1],)) for row in samplevld])
    vldy = [y[row] for row in samplevld]

    clf = linear_model.LinearRegression()
    clf.fit(x, y)
    # Calculate the loss value for each sample
    y_pred = clf.predict(x)
    losses = np.square(y - y_pred)
    # Sort by loss value from largest to smallest
    sorted_indices = np.argsort(losses)[::-1]
    # Take the first poisct samples with the largest loss value
    pois_indices = sorted_indices[:poisct]

    poisx = np.matrix(x[pois_indices])
    poisy = [y[row] for row in pois_indices]
    
    return trnx, trny, tstx, tsty, poisx, poisy, vldx, vldy
#--------------------------------------------------------------------------------
def sample_dataset_byLoss_trnct(x, y, trnct, poisct, tstct, vldct, seed):#
    size = x.shape[0]
    print(size)
    
    np.random.seed(seed)
    fullperm = np.random.permutation(size)

    sampletrn = fullperm[:trnct]
    sampletst = fullperm[trnct:trnct + tstct]
    samplevld = fullperm[trnct + tstct:trnct + tstct + vldct]
    #samplepois = np.random.choice(size, poisct)

    trnx = np.matrix([np.array(x[row]).reshape((x.shape[1],)) for row in sampletrn])
    trny = [y[row] for row in sampletrn]
   
    tstx = np.matrix([np.array(x[row]).reshape((x.shape[1],)) for row in sampletst])
    tsty = [y[row] for row in sampletst]
        
    vldx = np.matrix([np.array(x[row]).reshape((x.shape[1],)) for row in samplevld])
    vldy = [y[row] for row in samplevld]

    clf = linear_model.LinearRegression()
    clf.fit(trnx, trny)
    # Calculate the loss value for each sample
    y_pred = clf.predict(trnx)
    losses = np.square(trny - y_pred)
    # Sort by loss value from largest to smallest
    sorted_indices = np.argsort(losses)[::-1]
    # Take the first poisct samples with the largest loss value
    pois_indices = sorted_indices[:poisct]

    poisx = np.matrix(trnx[pois_indices])
    poisy = [trny[row] for row in pois_indices]
    
    return trnx, trny, tstx, tsty, poisx, poisy, vldx, vldy
#--------------------------------------------------------------------------------
def sample_dataset_byInfluence(x, y, trnct, poisct, tstct, vldct, seed):#
    size = x.shape[0]
    print(size)
    
    np.random.seed(seed)
    fullperm = np.random.permutation(size)

    sampletrn = fullperm[:trnct]
    sampletst = fullperm[trnct:trnct + tstct]
    samplevld = fullperm[trnct + tstct:trnct + tstct + vldct]
    #samplepois = np.random.choice(size, poisct)

    trnx = np.matrix([np.array(x[row]).reshape((x.shape[1],)) for row in sampletrn])
    trny = [y[row] for row in sampletrn]
   
    tstx = np.matrix([np.array(x[row]).reshape((x.shape[1],)) for row in sampletst])
    tsty = [y[row] for row in sampletst]
        
    vldx = np.matrix([np.array(x[row]).reshape((x.shape[1],)) for row in samplevld])
    vldy = [y[row] for row in samplevld]

    model1 = LinearRegression()
    model1.fit(trnx, trny)
    # Calculate the sum of squares of residuals
    residues = np.sum((model1.predict(trnx) - trny) ** 2)
    # Calculate the cookie's distance for each sample
    n_samples, n_features = trnx.shape
    hat = np.dot(np.dot(trnx, np.linalg.inv(np.dot(trnx.T, trnx))), trnx.T)
    cook = np.zeros(n_samples)

    for i in range(n_samples):
        #print(model1.predict(X[i]))
        
        exclude_idx = np.arange(len(trny)) != i
        #exclude_idx = np.where(exclude_idx)[0]
        X_excluded = trnx[exclude_idx]
        y_excluded = np.array(trny)[exclude_idx]
        #print(len(y_excluded))
        model2 = LinearRegression()
        model2.fit(X_excluded, y_excluded)
        #print(model2.predict(X_excluded[i]))
        diff = model1.predict(trnx[i].reshape(1, -1))-model2.predict(trnx[i].reshape(1, -1))
        cook[i] = (np.sum(diff **2)*hat[i,i])/(((1-hat[i,i])**2 )* (n_features * residues))
    # Find the sample with the largest Cook's distance
    sorted_indices = np.argsort(cook)[::-1]
    # Take the first poisct samples with the largest influence value
    pois_indices = sorted_indices[:poisct]
    poisx = np.matrix(trnx[pois_indices])
    poisy = [trny[row] for row in pois_indices]
    
    return trnx, trny, tstx, tsty, poisx, poisy, vldx, vldy

# ------------------------------------------------------------------------------- 
def infflip(x,y,count,poiser):
  mean = np.ravel(x.mean(axis=0))#.reshape(1,-1)
  corr = np.dot(x.T,x) + 0.01*np.eye(x.shape[1])
  invmat = np.linalg.pinv(corr)
  hmat = x*invmat*np.transpose(x)
  allgains = []
  for i in range(x.shape[0]):
    posgain = (np.sum(hmat[i])*(1-y[i]),1)
    neggain = (np.sum(hmat[i])*y[i],0)
    allgains.append(max(posgain,neggain))

  totalprob = sum([a[0] for a in allgains])
  allprobs = [0]
  for i in range(len(allgains)):
    allprobs.append(allprobs[-1]+allgains[i][0])
  allprobs=allprobs[1:]
  poisinds = []
  for i in range(count):
    a = np.random.uniform(low=0,high=totalprob)
    poisinds.append(bisect.bisect_left(allprobs,a))
  gainsy = [allgains[ind][1] for ind in poisinds]

  #sortedgains = sorted(enumerate(allgains),key = lambda tup: tup[1])[:count]
  #poisinds = [a[0] for a in sortedgains]
  #bestgains = [a[1][1] for a in sortedgains]

  return x[poisinds], gainsy


# ------------------------------------------------------------------------------- 
def inf_flip(X_tr, Y_tr,count):
  Y_tr = np.array(Y_tr)
  inv_cov = (0.01 * np.eye(X_tr.shape[1]) + np.dot(X_tr.T, X_tr)) ** -1
  H = np.dot(np.dot(X_tr, inv_cov), X_tr.T)
  bests = np.sum(H,axis = 1)
  room = .5 + np.abs(Y_tr-0.5)
  yvals = 1-np.floor(0.5+Y_tr)
  stat = np.multiply(bests.ravel(),room.ravel())
  stat = stat.tolist()[0]
  totalprob = sum(stat)
  allprobs = [0]
  poisinds = []
  for i in range(X_tr.shape[0]):
    allprobs.append(allprobs[-1]+stat[i])
  allprobs = allprobs[1:]
  for i in range(count):
    a = np.random.uniform(low=0,high=totalprob)
    poisinds.append(bisect.bisect_left(allprobs,a))
  
  return X_tr[poisinds], [yvals[a] for a in poisinds]

# ------------------------------------------------------------------------------- 













# ------------------------------------------------------------------------------- 
def roundpois(poisx,poisy):#Rounding and returning an integer value
  return np.around(poisx),[0 if val<0.5 else 1 for val in poisy]


# ------------------------------------------------------------------------------- 
# #datasets = ["icmldataset.txt",'contagio-preprocessed-missing.csv','pharm-preproc.csv','loan-processed.csv','house-processed.csv']
# ------------------------------------------------------------------------------- 
def main(args):
    trainfile, testfile, validfile, resfile, newlogdir =\
        open_logging_files(args.logdir, args.model, args.logind, args)
    x,y = open_dataset(args.dataset, args.visualize)
    trainx, trainy, testx, testy, poisx, poisy, validx, validy = \
        sample_dataset(x, y, args.trainct, args.poisct, args.testct, args.validct,\
                       args.seed) #edited by yannick
    
    for i in range(len(testy)):
        testfile.write(','.join([str(val) for val in [testy[i]]+testx[i].tolist()[0]]) + '\n')
    testfile.close()
    
    for i in range(len(validy)):
        validfile.write(','.join([str(val) for val in [validy[i]]+validx[i].tolist()[0]]) + '\n')
    validfile.close()

    for i in range(len(trainy)):
        trainfile.write(','.join([str(val) for val in [trainy[i]]+trainx[i].tolist()[0]]) + '\n')
        
    print(la.matrix_rank(trainx))
    print(trainx.shape)

    totprop = args.poisct/(args.poisct + args.trainct)#total poisoning rate
    print(totprop)

    timestart,timeend = None,None
    types = {'linreg': LinRegGDPoisoner,\
             'lasso': LassoGDPoisoner,\
             'enet': ENetGDPoisoner,\
             'ridge': RidgeGDPoisoner}

    inits = {'levflip': levflip,\
             'cookflip': cookflip,\
             'alfatilt': alfa_tilt,\
             'inflip': inf_flip,\
             'ffirst': farthestfirst,\
             'adaptive': adaptive,\
             'randflip': randflip,\
             'randflipnobd': randflipnobd,\
             'rmml': rmml}
    
    bestpoisx, bestpoisy, besterr = None, None, -1

    init = inits[args.initialization] #default='inflip'

    genpoiser = types[args.model](trainx, trainy, testx, testy, validx, validy,
                                  args.eta, args.beta, args.sigma, args.epsilon,
                                  args.multiproc,
                                  trainfile,resfile,args.objective,args.optimizey, colmap)
    
    for initit in range(args.numinit): #  Round of Initialization, default 1(can set nummit=0 to skip initialization) edited by yanxu
        poisx,poisy = init(trainx,trainy,int(args.trainct*totprop/(1-totprop)+0.5)) #initialize poisoning samples using inf_flip function above edited by yanxu
        clf, _ = genpoiser.learn_model(np.concatenate((trainx,poisx),axis=0),trainy+poisy,None) #1Train the model with initialized poison samples and original training sample points edited by yanxu
        err = genpoiser.computeError(clf)[0] #calculte mse of clf,return vld_mse, tst_mse,[0] means vld_mse edited by yanxu
        print("Validation Error:", err)
        if err > besterr:
            bestpoisx, bestpoisy, besterr = np.copy(poisx), poisy[:], err
    #poisx, poisy = np.matrix(bestpoisx), bestpoisy #original
            poisx, poisy = np.matrix(bestpoisx), bestpoisy#This line of code should be indented back within the scope of the if statement edited by yanxu
    poiser = types[args.model](trainx, trainy, testx, testy, validx, validy,\
                               args.eta, args.beta, args.sigma, args.epsilon,\
                               args.multiproc, trainfile, resfile,\
                               args.objective, args.optimizey, colmap)
    
    for i in range(args.partct + 1): #Perform sectionalized poisoning according to partct, contaminating one section of the sample each time,default partct=4,means 5 sections edited by yanxu
        #You can set partct=poison (number of poison samples) to achieve point by point pollution edited by yanxu
        curprop = (i + 1)*totprop/(args.partct + 1)
        numsamples = int(0.5 + args.trainct*(curprop/(1 - curprop)))
        curpoisx = poisx[:numsamples,:]
        curpoisy = poisy[:numsamples]
        trainfile.write("\n")

        timestart = datetime.datetime.now() #Record Start Time edited by yanxu
        poisres, poisresy = poiser.poison_data(curpoisx, curpoisy, timestart, args.visualize, newlogdir)
        print(poisres.shape,trainx.shape)
        poisedx = np.concatenate((trainx,poisres),axis = 0)
        poisedy = trainy + poisresy

        clfp, _ = poiser.learn_model(poisedx,poisedy,None) #Model after poisoning pollution edited by yanxu
        clf = poiser.initclf # Model trained with original x and y，return Model clf and regularization parameters lam edited by yanxu
        if args.rounding: #Rounding and returning an integer value，default rounding=false edited by yanxu
            roundx,roundy = roundpois(poisres,poisresy)
            rpoisedx,rpoisedy = np.concatenate((trainx,roundx),axis = 0),trainy + roundy
            clfr, _ = poiser.learn_model(rpoisedx,rpoisedy,None)
            rounderr = poiser.computeError(clfr)

        errgrd = poiser.computeError(clf)#Loss of original model edited by yanxu
        err = poiser.computeError(clfp)#Loss of model after pollution edited by yanxu

        timeend = datetime.datetime.now() #The time spent after polluting a section edited by yanxu

        towrite = [numsamples,-1,None,None,err[0],err[1],(timeend-timestart).total_seconds()]# err[0] vld_mse, err[1] tst_mse edited by yanxu
        resfile.write(','.join([str(val) for val in towrite])+"\n")
        trainfile.write("\n")
        for j in range(numsamples):
            trainfile.write(','.join([str(val) for val in [poisresy[j]]+poisres[j].tolist()[0]])+'\n')

        if args.rounding:
            towrite = [numsamples,'r',None,None,rounderr[0],rounderr[1],(timeend-timestart).total_seconds()]
            resfile.write(','.join([str(val) for val in towrite])+"\n")
            trainfile.write("\nround\n")
            for j in range(numsamples):
                trainfile.write(','.join([str(val) for val in [roundy[j]]+roundx[j].tolist()[0]])+'\n')

        resfile.flush()
        trainfile.flush()
        os.fsync(resfile.fileno())
        os.fsync(trainfile.fileno())
   
    trainfile.close()
    testfile.close()

    print()
    print("Unpoisoned")
    print("Validation MSE:",errgrd[0])
    print("Test MSE:",errgrd[1])
    print('Poisoned:')
    print("Validation MSE:",err[0])
    print("Test MSE:",err[1])
    if args.rounding:
        print("Rounded")
        print("Validation MSE",rounderr[0])
        print("Test MSE:", rounderr[1])



if __name__=='__main__':
    print("starting poison ...\n")
    parser = setup_argparse()
    args = parser.parse_args()

    print("-----------------------------------------------------------")
    print(args)
    print("-----------------------------------------------------------")
    main(args)
