from __future__ import division, print_function

# functional
import random
import numpy as np
import numpy.linalg as la
import bisect # for getting indices of values in inits

# logging etc.
import argparse
import os
import datetime

# visualization
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# sklearn imports
from sklearn import linear_model
from sklearn import svm
from sklearn import decomposition
from sklearn.datasets import make_regression

from math import sqrt, exp,ceil
from time import sleep
from sys import argv

#log_2 for python 2 or python 3
try:
    from math import log2
except:
    from math import log
    def log2(val):
        return log(val,2)


# makes multiprocessing work with classes
try:
  def _pickle_method(method):
    func_name = method.im_func.__name__
    obj = method.im_self
    cls = method.im_class
    return _unpickle_method, (func_name, obj, cls)

  def _unpickle_method(func_name, obj, cls):
    for cls in cls.mro():
      try:
        func = cls.__dict__[func_name]
      except KeyError:
        pass
      else:
        break
    return func.__get__(obj, cls)

  import copy_reg
  import types
  copy_reg.pickle(types.MethodType, _pickle_method, _unpickle_method)
except:
  pass


##############################################################################
# Gradient Descent Based Poisoners
##############################################################################

class GDPoisoner(object):
    def __init__(self, x, y, testx, testy, validx, validy, \
                eta, beta, sigma, eps, \
                mproc, \
                trainfile, resfile, \
                objective, opty, colmap):
        """
        GDPoisoner handles gradient descent and poisoning routines
        Computations for specific models found in respective classes

        x, y: training set
        testx, testy: test set
        validx, validy: validation set used for evaluation and stopping

        eta: gradient descent step size (note gradients are normalized)
        beta: decay rate for line search
        sigma: line search stop condition
        eps: poisoning stop condition

        mproc: whether to use multiprocessing to parallelize poisoning updates

        trainfile: file storing poisoning points in each iteration
        resfile: file storing each iteration's results in csv format

        objective: which objective to use
        opty: whether to optimize y
        colmap: map of columns for onehot encoded features
        """

        self.trnx = x
        self.trny = y
        self.tstx = testx
        self.tsty = testy
        self.vldx = validx
        self.vldy = validy

        self.samplenum = x.shape[0]
        self.feanum = x.shape[1]

        self.objective = objective
        self.opty = opty

        if (objective == 0): # training MSE + regularization
            self.attack_comp = self.comp_attack_trn
            self.obj_comp = self.comp_obj_trn

        elif (objective == 1): # validation MSE
            self.attack_comp = self.comp_attack_vld
            self.obj_comp = self.comp_obj_vld

        elif (objective == 2): # l2 distance between clean and poisoned
            self.attack_comp = self.comp_attack_l2
            self.obj_comp = self.comp_obj_new

        else:
            raise NotImplementedError

        self.mp = mproc # use multiprocessing?

        self.eta = eta
        self.beta = beta
        self.sigma = sigma
        self.eps = eps

        self.trainfile = trainfile
        self.resfile = resfile
        self.initclf,self.initlam = None,None

        self.colmap = colmap

    def poison_data(self,poisx,poisy,tstart,visualize,newlogdir):
        """
        poison_data takes an initial set of poisoning points and optimizes it
        using gradient descent with parameters set in __init__

        poisxinit, poisyinit: initial poisoning points 
        tstart: start time - used for writing out performance
        visualize: whether we want to visualize the gradient descent steps
        newlogdir: directory to log into, to save the visualization
        """

        poisct = poisx.shape[0]
        print("Poison Count: {}".format(poisct))

        new_poisx = np.zeros(poisx.shape)
        new_poisy = [None for a in poisy]

        best_poisx = np.zeros( poisx.shape )
        best_poisy = [None for a in poisy]

        best_obj = 0
        last_obj = 0
        count = 0

        if self.mp:# multi process default false
            import multiprocessing as mp
            workerpool = mp.Pool(max(1, mp.cpu_count()//2 - 1))
        else:
            workerpool = None
    
        sig = self.compute_sigma() # can already compute sigma and mu 
        mu = self.compute_mu()     # as x_c does not change them 
        eq7lhs = np.bmat([ [sig, np.transpose(mu)],
                           [mu,  np.matrix([1])] ] )
     
        # initial model - used in visualization
        clf_init, lam_init = self.learn_model(self.trnx, self.trny, None)
        clf, lam           = clf_init, lam_init

        # figure out starting error
        it_res = self.iter_progress(poisx, poisy,poisx, poisy)
    
        print("Iteration {}:".format(count))
        print("Objective Value: {} Change: {}".format(it_res[0], it_res[0]))# it_res[0] current loss on trainx,it_res[1] last loss on trainx 
        print("Validation MSE: {}".format(it_res[2][0]))
        print("Test MSE: {}".format(it_res[2][1]))

        last_obj = it_res[0]
        if it_res[0]>best_obj:#If the loss of this iteration is greater
            best_poisx, best_poisy, best_obj = poisx, poisy, it_res[0]
        
        # stuff to put into self.resfile
        towrite = [poisct, count, it_res[0], it_res[1], \
                   it_res[2][0], it_res[2][1], \
                   (datetime.datetime.now() - tstart).total_seconds()] #Time of this iteration 

        self.resfile.write( ','.join( [str(val) for val in towrite] ) + "\n" )
        self.trainfile.write("\n")
        self.trainfile.write(str(poisct) + "," + str(count) + '\n')

        if visualize:
            raise NotImplementedError
        else:
            for j in range(poisct):
                self.trainfile.write(','.join(
                            [str(val) for val
                              in [poisy[j]] + poisx[j].tolist()[0] \
                            ])+'\n')

        # main work loop
        while True:
            count += 1
            new_poisx = np.matrix(np.zeros(poisx.shape))
            new_poisy = [None for a in poisy]
            x_cur = np.concatenate( (self.trnx, poisx), axis = 0)
            y_cur = self.trny + poisy

            clf, lam = self.learn_model(x_cur, y_cur, None)         
            pois_params = [poisx, poisy, eq7lhs, mu, clf, lam, poisct]#
            outofboundsct = 0
            
            if workerpool: # multiprocessing
                for i, cur_pois_res in enumerate(
                                workerpool.map(self.poison_data_subroutine,
                                               pois_params)):

                    new_poisx[i]   = cur_pois_res[0]
                    new_poisy[i]   = cur_pois_res[1]
                    outofboundsct += cur_pois_res[2]

            else:
                #for i in range(poisct): #
                    cur_pois_res = self.poison_data_subroutine_batch(pois_params)#

                    new_poisx   = cur_pois_res[0]
                    new_poisy   = cur_pois_res[1]
                    outofboundsct += cur_pois_res[2]

          
            it_res = self.iter_progress(poisx, poisy, new_poisx, new_poisy)
           
            print("Iteration {}:".format(count))
            print("Objective Value: {} Change: {}".format(
                                it_res[0], it_res[0] - it_res[1]))#Training loss difference between two iterations 

            print("Validation MSE: {}".format(it_res[2][0]))
            print("Test MSE: {}".format(it_res[2][1]))
            print("Y pushed out of bounds: {}/{}".format(
                                        outofboundsct, poisct))
            
            # if we don't make progress, decrease learning rate
            if (it_res[0] < it_res[1]):
                print("no progress")
                self.eta *= 0.75
                new_poisx, new_poisy = poisx, poisy
            else:
                poisx = new_poisx
                poisy = new_poisy

            if (it_res[0] > best_obj):
                #best_poisx, best_poisy, best_obj = poisx, poisy, it_res[1] #original
                best_poisx, best_poisy, best_obj = poisx, poisy, it_res[0]#should put the best_obj update to the current mse it_res[0]
            last_obj = it_res[1]

            ##towrite = [poisct, count, it_res[0], it_res[1]-it_res[0],\ it_res[1] and it_res[0] are written backwards
            towrite = [poisct, count, it_res[0], it_res[0]-it_res[1],\
                       it_res[2][0], it_res[2][1], \
                       (datetime.datetime.now() - tstart).total_seconds()]

            self.resfile.write(','.join([str(val) for val in towrite])+"\n")
            self.trainfile.write("\n{},{}\n".format(poisct,count))

            for j in range(poisct):
                self.trainfile.write(','.join([str(val) for val in
                                     [new_poisy[j]] + new_poisx[j].tolist()[0]
                                     ])+'\n')
            it_diff = abs(it_res[0] - it_res[1])

            # stopping conditions
            if (count >= 15 and (it_diff <= self.eps or count > 50)):
                break

          
        if workerpool:
            workerpool.close()

        return best_poisx, best_poisy
    
    def poison_data_subroutine_batch(self,in_tuple):#
        """
        poison_data_subroutine poisons a single poisoning point
        input is passed in as a tuple and immediately unpacked for
        use with the multiprocessing.Pool.map function

        poisxelem, poisyelem: poisoning point at the start
        eq7lhs, mu: values for computation
        clf, lam: current model and regularization coef
        """

        poisxelem, poisyelem, eq7lhs, mu, clf, lam,poisct = in_tuple
        """
        The original code indicates that a single point is poisoned, 
        but now it is rewritten to poison a batch of sample points.
        The original (poisxelem, poisyelem) represents a single sample point, 
        poisxelem represents the (1, featurenum) feature vector, 
        and poisyelem represents the label corresponding to the (1, 1) feature vector; 
        The current (poisxelem, poisyelem) represents poisct sample points, 
        recording the feature matrix and label vector of poisct sample points, 
        where poisxelem represents a vector of (poisct, featurenum), 
        and poisyelem represents a vector of poisct size. 
        The original attack(1,feanum) and attacky(1,1) represent the gradients of 
        the mean square deviation loss function on x and y for a single point.
        Now,attack denotes [(1,feanum),...,(1,feanum)] vector, size of which is poisct.
        Attacky denotes [(1,1),...,(1,1)] vector, size of which is poisct."""
        for i in range(poisct):
            m = np.empty(poisct , dtype=np.object)
            wxc=np.empty(poisct , dtype=np.object)
            bxc=np.empty(poisct , dtype=np.object)
            wyc=np.empty(poisct , dtype=np.object)
            byc=np.empty(poisct , dtype=np.object)
            attack=np.empty(poisct , dtype=np.object)
            attacky = np.empty(poisct , dtype=np.object)
            allattack=np.empty(poisct , dtype=np.object)
            norm=np.empty(poisct , dtype=np.object)
            for i in range(poisct):
                m[i] = np.empty((self.feanum, self.feanum))
                wxc[i] = np.empty((self.feanum, self.feanum))
                bxc[i] = np.empty((1, self.feanum))
                wyc[i] = np.empty(( self.feanum,1))
                byc[i] = np.empty((1, 1))
                attack[i] = np.empty((1, self.feanum))
                attacky[i] = np.empty(1)
                allattack[i] = np.empty((1, self.feanum+1))
                norm[i] = np.empty((poisct, 1))
            m[i] = self.compute_m(clf, poisxelem[i], poisyelem[i])
        
            # compute partials
            

            wxc[i], bxc[i], wyc[i], byc[i] = self.compute_wb_zc(eq7lhs, mu, clf.coef_, m[i],\
                                                self.samplenum, poisxelem[i])
            if (self.objective == 0):
                r = self.compute_r(clf, lam)
                otherargs = (r,)
            else:
                otherargs = None
        
            attack[i], attacky[i] = self.attack_comp(clf, wxc[i], bxc[i], wyc[i], byc[i], otherargs)#default comp_attack_trn,Can be simply understood as calculating a gradient
            
            # keep track of how many points are pushed out of bounds
            if (poisyelem[i] >= 1 and attacky[i] >= 0)\
                or (poisyelem[i] <= 0 and attacky[i] <= 0):
                outofbounds = True
            else:
                outofbounds = False

            #include y in gradient normalization
            if self.opty:
                allattack[i] = np.array(np.concatenate((attack[i], attacky[i]), axis=1))
                allattack[i] = allattack[i].ravel()
                
                
            else:
                for i in range(poisct):
                    allattack[i] = np.empty((1, self.feanum))    
                allattack[i] = attack[i].ravel()
        
            norm[i] = np.linalg.norm(allattack[i])
            allattack[i] = allattack[i]/norm[i] if norm[i]>0 else allattack[i]
            if self.opty:
                #attack[i], attacky[i] = np.reshape(allattack[i][:-1],(1,self.feanum)),np.reshape(allattack[i][-1],(1,1))
               
                attack[i], attacky[i] = np.reshape(allattack[i][:-1],(1,self.feanum)),allattack[i][-1]
                
            else:
                attack[i] = allattack[i]
        

        poisxelem, poisyelem= self.lineSearch_batch(poisxelem, poisyelem,\
                                                     attack, attacky)
        #poisxelem = poisxelem.reshape((1,self.feanum))

        return poisxelem, poisyelem, outofbounds


    def computeError(self, clf):
        toterr, v_toterr = 0, 0
        rsqnum, v_rsqnum = 0, 0
        rsqdenom, v_rsqdenom = 0, 0

        w = np.reshape(clf.coef_, (self.feanum,))
        sum_w = np.linalg.norm(w,1)

        mean = sum(self.tsty)/len(self.tsty)
        vmean = sum(self.vldy)/len(self.vldy)

        pred  = clf.predict(self.tstx) 
        vpred = clf.predict(self.vldx)

        for i, trueval in enumerate(self.vldy):
            guess = vpred[i]
            err = guess - trueval

            v_toterr   += err**2 # MSE
            v_rsqnum   += (guess-vmean)**2 # R^2 num and denom
            v_rsqdenom += (trueval-vmean)**2
    
        for i,trueval in enumerate(self.tsty):
            guess = pred[i]
            err = guess-trueval

            toterr   += err**2 # MSE
            rsqnum   += (guess-mean)**2 # R^2 num and denom
            rsqdenom += (trueval-mean)**2

        vld_mse = v_toterr/len(self.vldy)
        tst_mse = toterr/len(self.tsty)

        return vld_mse, tst_mse
        # computed a bunch of other stuff too
        # sum_w,rsqnum/rsqdenom,v_rsqnum/v_rsqdenom


    def lineSearch_batch(self,poisxelem, poisyelem,attack,attacky):
        
        k = 0
        x0 = np.copy(self.trnx)
        y0 = self.trny[:]
        
        curx = np.append(x0, poisxelem, axis=0)
        cury = y0[:] # why not?
        

        lastpoisxelem = poisxelem
        curpoisxelem = poisxelem

        lastyc = poisyelem
        curyc = poisyelem
        
        otherargs = None

        eta = self.eta*self.beta

        curpoisxelem = curpoisxelem + eta*np.concatenate(attack, axis=0)\
                            .reshape(curpoisxelem.shape[0],curpoisxelem.shape[1])

        curpoisxelem = np.clip(curpoisxelem, 0, 1)
        curx[-curpoisxelem.shape[0]:] = curpoisxelem
        
               
        
        return np.clip(curpoisxelem, 0, 1), curyc


    def iter_progress(self, lastpoisx, lastpoisy, curpoisx, curpoisy):
        x0 = np.concatenate((self.trnx, lastpoisx), axis = 0)
        y0 = self.trny + lastpoisy
        clf0, lam0 = self.learn_model(x0, y0, None)
        w_0 = self.obj_comp(clf0, lam0, None)#Total loss from previous iteration(for training data)

        x1 = np.concatenate((self.trnx, curpoisx), axis = 0)
        y1 = self.trny + curpoisy
        clf1, lam1 = self.learn_model(x1, y1, None)
        w_1 = self.obj_comp(clf1, lam1, None)#Overall loss of current iteration(for training data)
        err = self.computeError(clf1)#vld and tst Loss of the current iteration 
        return w_1, w_0, err
    
############################################################################################
# Implements GD Poisoning for OLS Linear Regression
############################################################################################

class LinRegGDPoisoner(GDPoisoner):
    def __init__(self, x, y, testx, testy, validx, validy, \
                eta, beta, sigma, eps, \
                mproc, \
                trainfile, resfile, \
                objective, opty, colmap):
        """
        LinRegGDPoisoner implements computations for ordinary least
        squares regression. Computations involving regularization are
        handled in the respective children classes

        for input description, see GDPoisoner.__init__
        """

        GDPoisoner.__init__(self, x, y, testx, testy, validx, validy, \
                            eta, beta, sigma, eps, mproc, \
                            trainfile, resfile, \
                            objective, opty, colmap)
        #self.initclf, self.initlam = self.learn_model(self.x,self.y,None) #original
    
        self.initclf, self.initlam = self.learn_model(x,y,None)#x and y are parameters passed externally to the class GDPoisoner and cannot become attributes of the object 

    def learn_model(self, x, y, clf):
        if (not clf):
            clf = linear_model.Ridge(alpha=0.00001)
        clf.fit(x, y)
        return clf, 0

    def compute_sigma(self):
        sigma = np.dot(np.transpose(self.trnx), self.trnx)
        sigma = sigma / self.trnx.shape[0]
        return sigma

    def compute_mu(self):
        mu = np.mean(self.trnx, axis=0)
        return mu

    def compute_m(self, clf, poisxelem, poisyelem):
        w,b = clf.coef_, clf.intercept_
        poisxelemtransp = np.reshape(poisxelem, (self.feanum,1) )
        wtransp = np.reshape(w, (1,self.feanum) )
        errterm = (np.dot(w, poisxelemtransp) + b - poisyelem).reshape((1,1))
        first = np.dot(poisxelemtransp,wtransp)
        m = first + errterm[0,0]*np.identity(self.feanum)
        return m

    def compute_wb_zc(self,eq7lhs, mu, w, m, n,poisxelem):

        eq7rhs = -(1/n)*np.bmat([[m,             -np.matrix(poisxelem.T)],
                                 [np.matrix(w.T), np.matrix([-1])       ]])
        #print("eq7rhs' shape is:")
        #print(eq7rhs.shape)
        wbxc = np.linalg.lstsq(eq7lhs,eq7rhs,rcond=None)[0]
        wxc = wbxc[:-1,:-1] # get all but last row#
        bxc = wbxc[ -1,:-1] # get last row
        wyc = wbxc[:-1, -1]
        byc = wbxc[ -1, -1]
        return wxc,bxc.ravel(),wyc.ravel(),byc#wyc.shape=(4,1),wyc.ravel().shape=(1,4)

    def compute_r(self,clf,lam):
        r = np.zeros((1,self.feanum))
        return r

    def comp_obj_trn(self,clf,lam,otherargs):
        errs = clf.predict(self.trnx) - self.trny
        mse = np.linalg.norm(errs)**2 / self.samplenum

        return mse

    def comp_obj_vld(self,clf,lam,otherargs):
        m = self.vldx.shape[0]
        errs = clf.predict(self.vldx) - self.vldy
        mse = np.linalg.norm(errs)**2 / m
        return mse
   
    def comp_attack_trn(self,clf,wxc,bxc,wyc,byc,otherargs):
        res = (clf.predict(self.trnx) - self.trny)
        
        gradx = np.dot(self.trnx, wxc)   + bxc
        grady = np.dot(self.trnx, wyc.T) + byc # wyc.T.shape=(4,1)

        attackx = np.dot(res,gradx) / self.samplenum #attackx is a d-dimensional vector 
        attacky = np.dot(res,grady) / self.samplenum #attacky is a number 
   
        return attackx, attacky

    def comp_attack_vld(self,clf,wxc,bxc,wyc,byc,otherargs):
        n = self.vldx.shape[0]
        res = (clf.predict(self.vldx)-self.vldy)

        gradx = np.dot(self.vldx, wxc)   + bxc
        grady = np.dot(self.vldx, wyc.T) + byc

        attackx = np.dot(res,gradx) / n
        attacky = np.dot(res,grady) / n

        return attackx, attacky


