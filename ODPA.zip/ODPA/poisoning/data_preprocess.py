import pandas as pd
from sklearn.preprocessing import MinMaxScaler
#Read raw dataset
data = pd.read_excel("D:/MlDpaExperiment/DPA-SelectedPoints/CCPP/Folds5x2_pp.xlsx", engine='openpyxl')
# Extract feature columns and label columns
X = data.iloc[:, :-1].values
y = data.iloc[:, -1].values
# Normalization processing
scaler = MinMaxScaler()
X = scaler.fit_transform(X)
y = scaler.fit_transform(y.reshape(-1, 1)).ravel()
# Store the normalized feature matrix, label columns, and corresponding headers in a new table
df = pd.DataFrame(X, columns=data.columns[:-1])
df[data.columns[-1]] = y
#Save the new table to a file
df.to_csv("D:/MlDpaExperiment/MmlDpadRlJagielsli/datasets/ccpp.csv", index=False)